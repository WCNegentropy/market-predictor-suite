import type { CommandModule } from 'yargs';

interface HelloArgs {
  name: string;
}

export const helloCommand: CommandModule<object, HelloArgs> = {
  command: 'hello',
  describe: 'Say hello',
  builder: {
    name: {
      alias: 'n',
      type: 'string' as const,
      default: 'World',
      describe: 'Name to greet',
    },
  },
  handler: (argv) => {
    console.log(`Hello, ${argv.name}!`);
  },
};
