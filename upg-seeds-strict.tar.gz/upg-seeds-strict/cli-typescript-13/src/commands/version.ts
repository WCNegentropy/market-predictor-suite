import type { CommandModule } from 'yargs';

export const versionCommand: CommandModule = {
  command: 'info',
  describe: 'Show version info',
  handler: () => {
    console.log('mps-cli-typescript-13 v0.1.0');
  },
};
