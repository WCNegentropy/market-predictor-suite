/**
 * Generate a greeting message.
 * @param {object} options
 * @param {string} options.name
 * @param {string} [options.greeting='Hello']
 * @returns {string}
 */
export function greet({ name, greeting = 'Hello' }) {
  return `${greeting}, ${name}!`;
}

/**
 * Add two numbers.
 * @param {number} a
 * @param {number} b
 * @returns {number}
 */
export function add(a, b) {
  return a + b;
}
