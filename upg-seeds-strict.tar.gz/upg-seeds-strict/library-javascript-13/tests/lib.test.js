import { describe, it, expect } from 'vitest';
import { greet, add } from '../src/lib.js';

describe('greet', () => {
  it('should greet with default greeting', () => {
    expect(greet({ name: 'World' })).toBe('Hello, World!');
  });

  it('should greet with custom greeting', () => {
    expect(greet({ name: 'World', greeting: 'Hi' })).toBe('Hi, World!');
  });
});

describe('add', () => {
  it('should add two numbers', () => {
    expect(add(1, 2)).toBe(3);
  });
});
