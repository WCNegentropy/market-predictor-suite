import type { Command } from 'commander';

export function versionCommand(program: Command): void {
  program
    .command('info')
    .description('Show version info')
    .action(() => {
      console.log('mps-cli-typescript-7 v0.1.0');
    });
}
