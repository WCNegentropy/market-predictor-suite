# mps-cli-typescript-7

![TypeScript](https://img.shields.io/badge/TypeScript-blue) ![commander](https://img.shields.io/badge/commander-green)

A cli tool built with TypeScript and commander.

## Tech Stack

- **Language:** TypeScript
- **Framework:** commander
- **Database:** None
- **Runtime:** node

## Getting Started

### Prerequisites

- Node.js 20+
- pnpm 8+

### Installation

```bash
# Install dependencies
pnpm install

# Run development server
pnpm dev

# Build for production
pnpm build

# Run tests
pnpm test
```

## Project Structure

```
mps-cli-typescript-7/
├── src/
│   └── index.ts
├── package.json
├── tsconfig.json
└── README.md
```

## Development

### Docker

You can run this project using Docker:

```bash
docker-compose up
```

## License

MIT
