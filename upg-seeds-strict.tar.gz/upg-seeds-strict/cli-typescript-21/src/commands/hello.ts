import type { Command } from 'commander';

export function helloCommand(program: Command): void {
  program
    .command('hello')
    .description('Say hello')
    .option('-n, --name <name>', 'Name to greet', 'World')
    .action((options: { name: string }) => {
      console.log(`Hello, ${options.name}!`);
    });
}
