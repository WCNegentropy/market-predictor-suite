#!/usr/bin/env node
import { program } from 'commander';
import { helloCommand } from './commands/hello.js';
import { versionCommand } from './commands/version.js';

program
  .name('mps-cli-javascript-21')
  .description('mps-cli-javascript-21 CLI')
  .version('0.1.0');

helloCommand(program);
versionCommand(program);

program.parse();
