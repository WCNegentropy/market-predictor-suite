export function helloCommand(program) {
  program
    .command('hello')
    .description('Say hello')
    .option('-n, --name <name>', 'Name to greet', 'World')
    .action((options) => {
      console.log(`Hello, ${options.name}!`);
    });
}
