import { describe, it, expect } from 'vitest';

describe('hello command', () => {
  it('should greet with default name', () => {
    // Basic smoke test
    expect(true).toBe(true);
  });
});
