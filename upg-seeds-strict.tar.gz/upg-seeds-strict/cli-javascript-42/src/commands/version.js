export function versionCommand(program) {
  program
    .command('info')
    .description('Show version info')
    .action(() => {
      console.log('mps-cli-javascript-42 v0.1.0');
    });
}
