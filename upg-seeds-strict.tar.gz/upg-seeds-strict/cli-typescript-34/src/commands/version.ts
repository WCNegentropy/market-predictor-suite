import type { CommandModule } from 'yargs';

export const versionCommand: CommandModule = {
  command: 'info',
  describe: 'Show version info',
  handler: () => {
    console.log('mps-cli-typescript-34 v0.1.0');
  },
};
