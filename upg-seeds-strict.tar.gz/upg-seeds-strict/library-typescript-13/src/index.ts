export { greet, add } from './lib.js';
export type { GreetOptions } from './lib.js';
