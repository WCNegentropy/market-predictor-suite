/**
 * Options for the greet function.
 */
export interface GreetOptions {
  name: string;
  greeting?: string;
}

/**
 * Generate a greeting message.
 */
export function greet(options: GreetOptions): string {
  const { name, greeting = 'Hello' } = options;
  return `${greeting}, ${name}!`;
}

/**
 * Add two numbers.
 */
export function add(a: number, b: number): number {
  return a + b;
}
