import yargs from 'yargs';
import { hideBin } from 'yargs/helpers';
import { helloCommand } from './commands/hello.js';
import { versionCommand } from './commands/version.js';

yargs(hideBin(process.argv))
  .scriptName('mps-cli-typescript-42')
  .usage('$0 <command> [options]')
  .command(helloCommand)
  .command(versionCommand)
  .demandCommand(1, 'You need at least one command')
  .strict()
  .help()
  .parse();
