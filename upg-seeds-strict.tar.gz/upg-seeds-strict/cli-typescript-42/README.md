# mps-cli-typescript-42

![TypeScript](https://img.shields.io/badge/TypeScript-blue) ![yargs](https://img.shields.io/badge/yargs-green)

A cli tool built with TypeScript and yargs.

## Tech Stack

- **Language:** TypeScript
- **Framework:** yargs
- **Database:** None
- **Runtime:** node

## Getting Started

### Prerequisites

- Node.js 20+
- pnpm 8+

### Installation

```bash
# Install dependencies
pnpm install

# Run development server
pnpm dev

# Build for production
pnpm build

# Run tests
pnpm test
```

## Project Structure

```
mps-cli-typescript-42/
├── src/
│   └── index.ts
├── package.json
├── tsconfig.json
└── README.md
```

## Development

### Docker

You can run this project using Docker:

```bash
docker-compose up
```

## License

MIT
